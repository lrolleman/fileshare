#include <cnet.h>

extern	void	init_clickwalk(void);
